#ifndef COLOR_H
#define COLOR_H

typedef struct color
{
	uint8_t r;
	uint8_t g;
	uint8_t b;
}color_t;

#endif